package ir.abrak.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF7650D8)
private val DeepPurple = Color(0xFF5030A8)
private val Pale = Color(0xFFF8F6FF)
private val Ink = Color(0xFF28223A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AbrakApp() }
    }
}

@Composable
private fun AbrakApp() {
    var loggedIn by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Pale, surface = Color.White)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Pale) {
            Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFDFBFF), Color(0xFFECE5FF), Pale)))) {
                if (loggedIn) Dashboard(onLogout = { loggedIn = false })
                else LoginScreen(onLoginPreview = { loggedIn = true })
            }
        }
    }
}

@Composable
private fun LoginScreen(onLoginPreview: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(modifier = Modifier.size(88.dp).background(Brush.linearGradient(listOf(Purple, DeepPurple)), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Shield, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("Abrak VPN", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = DeepPurple)
        Text("اتصال امن، ساده و سریع", color = Color(0xFF777087), fontSize = 14.sp)
        Spacer(Modifier.height(28.dp))
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.86f)), elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("ورود به حساب", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                OutlinedTextField(value = username, onValueChange = { username = it; message = "" }, modifier = Modifier.fillMaxWidth(), label = { Text("نام کاربری") }, singleLine = true, shape = RoundedCornerShape(16.dp))
                OutlinedTextField(
                    value = password, onValueChange = { password = it; message = "" }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("رمز عبور") }, singleLine = true, shape = RoundedCornerShape(16.dp),
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { IconButton(onClick = { showPassword = !showPassword }) { Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = "نمایش رمز") } }
                )
                Button(onClick = {
                    message = if (username.isBlank() || password.isBlank()) "نام کاربری و رمز عبور را وارد کن." else "ورود سرور هنوز متصل نشده است؛ این نسخه فقط پیش‌نمایش رابط کاربری است."
                }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.Lock, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("ورود", fontWeight = FontWeight.Bold)
                }
                if (message.isNotBlank()) Text(message, color = Color(0xFF8A3E79), fontSize = 12.sp)
                Text("ثبت‌نام عمومی غیرفعال است؛ حساب‌ها توسط مدیر ساخته می‌شوند.", color = Color(0xFF817A91), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("WHITE • PURPLE • GLASS UI", color = Color(0xFF8B7BB5), fontSize = 10.sp, letterSpacing = 2.sp)
    }
}

@Composable
private fun Dashboard(onLogout: () -> Unit) {
    var connected by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Abrak VPN", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = DeepPurple)
                Text("پنل اتصال شما", color = Color(0xFF777087))
            }
            TextButton(onClick = onLogout) { Text("خروج") }
        }
        Spacer(Modifier.height(22.dp))
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.88f)), elevation = CardDefaults.cardElevation(8.dp)) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(110.dp).background(Brush.linearGradient(listOf(Purple, DeepPurple)), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = Color.White, modifier = Modifier.size(60.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text(if (connected) "متصل" else "آماده اتصال", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = if (connected) Color(0xFF23865B) else Ink)
                Text("موتور اتصال VPN هنوز نصب و پیکربندی نشده است", color = Color(0xFF777087), fontSize = 12.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick = { connected = !connected }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                    Text(if (connected) "قطع اتصال نمایشی" else "اتصال نمایشی", fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard("پینگ", "— ms", Icons.Default.Speed, Modifier.weight(1f))
            InfoCard("اعتبار", "پس از ورود", Icons.Default.Lock, Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.8f))) {
            Column(Modifier.padding(18.dp)) {
                Text("سرورها", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
                Spacer(Modifier.height(8.dp))
                Text("فهرست سرورها پس از اتصال به API پنل نمایش داده می‌شود.", color = Color(0xFF777087), fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.86f))) {
        Column(Modifier.padding(16.dp)) {
            Icon(icon, contentDescription = null, tint = Purple)
            Spacer(Modifier.height(8.dp))
            Text(title, color = Color(0xFF777087), fontSize = 12.sp)
            Text(value, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
